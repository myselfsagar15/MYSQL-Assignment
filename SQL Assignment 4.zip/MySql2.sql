----------------------------------------------------------------------------------------------
                                   /* SQL ASSIGNMENT 2*/


                                                                     /* BY SAGAR BANGERA */
----------------------------------------------------------------------------------------------  

----------------------------------------------------------------------------------------------
/*  Task1. Understanding the Data */
----------------------------------------------------------------------------------------------

	   /*  1. Describe the data in hand in your own words. 
		--------------------------------------------------------------------------------------
		Here is a database consisting of Sales of a Superstore.
		It consists of 5 tables such as:
			1. cust_dimen: Details of all the customers
				
				Customer_Name (TEXT): Name of the customer
				Province (TEXT): Province of the customer
				Region (TEXT): Region of the customer
				Customer_Segment (TEXT): Segment of the customer
				Cust_id (TEXT): Unique Customer ID
			
			2. market_fact: Details of every order item sold
				
				Ord_id (TEXT): Order ID
				Prod_id (TEXT): Prod ID
				Ship_id (TEXT): Shipment ID
				Cust_id (TEXT): Customer ID
				Sales (DOUBLE): Sales from the Item sold
				Discount (DOUBLE): Discount on the Item sold
				Order_Quantity (INT): Order Quantity of the Item sold
				Profit (DOUBLE): Profit from the Item sold
				Shipping_Cost (DOUBLE): Shipping Cost of the Item sold
				Product_Base_Margin (DOUBLE): Product Base Margin on the Item sold
				
			3. orders_dimen: Details of every order placed
				
				Order_ID (INT): Order ID
				Order_Date (TEXT): Order Date
				Order_Priority (TEXT): Priority of the Order
				Ord_id (TEXT): Unique Order ID
			
			4. prod_dimen: Details of product category and sub category
				
				Product_Category (TEXT): Product Category
				Product_Sub_Category (TEXT): Product Sub Category
				Prod_id (TEXT): Unique Product ID
			
			5. shipping_dimen: Details of shipping of orders
				
				Order_ID (INT): Order ID
				Ship_Mode (TEXT): Shipping Mode
				Ship_Date (TEXT): Shipping Date
				Ship_id (TEXT): Unique Shipment*
        ----------------------------------------------------------------------------------------------
        2. Identify and list the Primary Keys and Foreign Keys for this dataset provided to you
        ----------------------------------------------------------------------------------------------
			1. cust_dimen: Primary Key: Cust_id, Foreign Key: NONE
		
			2. market_fact: Primary Key: NONE, Foreign Key: Ord_id, Prod_id, Ship_id, Cust_id
			
			3. orders_dimen: Primary Key: Ord_id, Foreign Key: NONE
			
			4. prod_dimen: Primary Key: Prod_id, Product_Sub_Category, Foreign Key: NONE
			
			5. shipping_dimen: Primary Key: Ship_id, Foreign Key: NONE          */
----------------------------------------------------------------------------------------------               
/* Task 2:- Basic & Advanced Analysis  */
----------------------------------------------------------------------------------------------
use superstores;


/* 1. Write a query to display the Customer_Name and Customer Segment using alias name “Customer Name", "Customer Segment" from table Cust_dimen*/
----------------------------------------------------------------------------------------------

select Customer_Name as "Customer Name", Customer_Segment as "Customer Segment" from cust_dimen;

----------------------------------------------------------------------------------------------
/* 2. Write a query to find all the details of the customer from the table cust_dimen order by desc. */
----------------------------------------------------------------------------------------------

select * from cust_dimen order by Customer_Name desc;

----------------------------------------------------------------------------------------------
/* 3. Write a query to get the Order ID, Order date from table orders_dimen where ‘Order Priority’ is high */
----------------------------------------------------------------------------------------------

select Order_ID,Order_Date from orders_dimen where Order_Priority like 'high';

----------------------------------------------------------------------------------------------
/* 4. Find the total and the average sales (display total_sales and avg_sales)  */
----------------------------------------------------------------------------------------------

select sum(Sales) as total_sales, avg(Sales) as avg_sales from market_fact;

----------------------------------------------------------------------------------------------
/* 5. Write a query to get the maximum and minimum sales from maket_fact table. */
----------------------------------------------------------------------------------------------

select max(Sales),min(Sales) from market_fact;

----------------------------------------------------------------------------------------------
/* 6. Display the number of customers in each region in decreasing order of no_of_customers. The result should contain columns Region, no_of_customers. */
----------------------------------------------------------------------------------------------

select Region,count(*) as no_of_customers from cust_dimen group by Region order by no_of_customers desc;

----------------------------------------------------------------------------------------------
/* 7. Find the region having maximum customers (display the region name and max(no_of_customers) */
----------------------------------------------------------------------------------------------

select Region,count(*) as no_of_customers from cust_dimen group by Region having no_of_customers >= all (select count(*) as no_of_customers from cust_dimen group by Region);

----------------------------------------------------------------------------------------------
/*8. Find all the customers from Atlantic region who have ever purchased ‘TABLES’ and the number of tables purchased (display the customer name, no_of_tables purchased)  */
----------------------------------------------------------------------------------------------

select cust_dimen.Region,cust_dimen.Customer_Name as CustomerName,prod_dimen.Product_Sub_Category,sum(market_fact.Order_Quantity) as No_of_tables_purchased from market_fact join cust_dimen on market_fact.Cust_id =cust_dimen.Cust_id 
join prod_dimen on market_fact.Prod_id = prod_dimen.Prod_id where cust_dimen.Region ='ATLANTIC' and prod_dimen.Product_Sub_Category= 'TABLES' group by cust_dimen.Customer_Name order by sum(market_fact.Order_Quantity) desc;

----------------------------------------------------------------------------------------------
/* 9. Find all the customers from Ontario province who own Small Business. (display the customer name, no of small business owners) */
----------------------------------------------------------------------------------------------

select Customer_Name,Customer_Segment from cust_dimen where Customer_Segment ="small business";
----------------------------------------------------------------------------------------------
           /*Numeric value of total customers who own small business */
/* 9. Find all the customers from Ontario province who own Small Business. (display the customer name, no of small business owners) */
----------------------------------------------------------------------------------------------

select count(Customer_Segment) as Total_Customers from cust_dimen where Customer_Segment ="small business";

----------------------------------------------------------------------------------------------
/* 10. Find the number and id of products sold in decreasing order of products sold (display product id, no_of_products sold)  */
----------------------------------------------------------------------------------------------

select Prod_id,count(*) as no_of_products_sold from market_fact group by Prod_id order by no_of_products_sold desc;

----------------------------------------------------------------------------------------------
/* 11. Display product Id and product sub category whose produt category belongs to Furniture and Technlogy. The result should contain columns product id, product sub category. */
----------------------------------------------------------------------------------------------

select Prod_id,Product_Sub_Category from prod_dimen where Product_Category ="furniture" or Product_Category="technology";

----------------------------------------------------------------------------------------------
/* 12. Display the product categories in descending order of profits (display the product category wise profits i.e. product_category, profits)? */
----------------------------------------------------------------------------------------------

select prod_dimen.Product_Category,sum(market_fact.Profit) as Profit from market_fact join prod_dimen on market_fact.Prod_id =prod_dimen.Prod_id group by prod_dimen.Product_Category order by sum(market_fact.Profit) desc;

----------------------------------------------------------------------------------------------
/* 13. Display the product category, product sub-category and the profit within each subcategory in three columns */
----------------------------------------------------------------------------------------------

select prod_dimen.Product_Category,prod_dimen.Product_Sub_Category,sum(market_fact.Profit) as Profit from market_fact join prod_dimen on prod_dimen.Prod_id = market_fact.Prod_id group by prod_dimen.Product_Category,prod_dimen.Product_Sub_Category;

----------------------------------------------------------------------------------------------
/* 14. Display the order date, order quantity and the sales for the order. */
----------------------------------------------------------------------------------------------

select sum(market_fact.Sales) as Sales,sum(market_fact.Order_Quantity) as Order_Quantity,orders_dimen.Order_Date from orders_dimen join market_fact on orders_dimen.Ord_id = market_fact.Ord_id group by orders_dimen.Order_Date;

----------------------------------------------------------------------------------------------
/* 15. Display the names of the customers whose name contains the
 i) Second letter as ‘R’
 ii) Fourth letter as ‘D’ */
 ----------------------------------------------------------------------------------------------
 
select Customer_Name from cust_dimen where Customer_Name like '_r_d%';

----------------------------------------------------------------------------------------------
/* 16. Write a SQL query to to make a list with Cust_Id, Sales, Customer Name and their region where sales are between 1000 and 5000. */
----------------------------------------------------------------------------------------------

select cust_dimen.Cust_id,cust_dimen.Customer_Name,cust_dimen.Region,market_fact.Sales from market_fact join cust_dimen on cust_dimen.Cust_id = market_fact.Cust_id  where market_fact.Sales between 1000 and 5000 group by Cust_id; 

----------------------------------------------------------------------------------------------
/* 17. Write a SQL query to find the 3rd highest sales. */
----------------------------------------------------------------------------------------------

select Sales from market_fact order by Sales desc limit 1 offset 2;

----------------------------------------------------------------------------------------------
/*18. Where is the least profitable product subcategory shipped the most? For the least profitable product sub-category, display the region-wise no_of_shipments and the profit made in each region in decreasing order of profits (i.e. region,no_of_shipments, profit_in_each_region)*/
----------------------------------------------------------------------------------------------

select cust_dimen.Region, count(distinct market_fact.Ship_id) as No_Of_Shipments, sum(market_fact.Profit) as Profit_in_each_region from market_fact join cust_dimen on cust_dimen.Cust_id = market_fact.Cust_id join prod_dimen on prod_dimen.Prod_id = market_fact.Prod_id 
where prod_dimen.Product_Sub_Category = (select prod_dimen.Product_Sub_Category from market_fact join prod_dimen on market_fact.Prod_id=prod_dimen.Prod_id group by Product_Sub_Category order by sum(market_fact.Profit) limit 1) group by cust_dimen.Region order by sum(market_fact.Profit);

